package com.pretest.model;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ProductDetailsInput {
    private String productId;
}
